let nina;
let arvores = [];
let lixos = [];
let passaros = [];
let temperatura = 20;
let pontos = 100;
let gameOver = false;
let largura = 800;
let altura = 600;
let fase = 1;
let ferramentaAtiva = false;
let faseDificuldade = 1;
let tempoDefesa = 0;
let duracaoDefesa = 300;
let gramaAltura = 150;
let chuvaAcida = false;
let gotasChuva = [];

function setup() {
  createCanvas(largura, altura);
  textFont('Arial');
  nina = new Nina(largura / 2, altura - gramaAltura / 2);
  frameRate(60);
  for (let i = 0; i < 5; i++) {
    passaros.push(new Passaro(random(width), random(50, 150)));
  }
  for (let i = 0; i < 200; i++) {
    gotasChuva.push(new Gota());
  }
}

function draw() {
  background(135, 206, 235);
  if (gameOver) {
    showGameOver();
    return;
  }

  desenharCenario();

  for (let passaro of passaros) {
    passaro.move();
    passaro.display();
  }

  if (frameCount % 300 === 0) {
    chuvaAcida = !chuvaAcida;
  }

  if (chuvaAcida) {
    for (let gota of gotasChuva) {
      gota.update();
      gota.display();
      for (let arvore of arvores) {
        if (dist(gota.x, gota.y, arvore.x, arvore.y) < 10) {
          pontos -= 1;
        }
      }
    }
  }

  nina.display();
  nina.update();

  temperatura += random(-0.2, 0.2);
  temperatura = constrain(temperatura, 10, 35);

  for (let i = arvores.length - 1; i >= 0; i--) {
    arvores[i].display();
    arvores[i].grow(temperatura);
    if (arvores[i].size > 50) {
      pontos += 10;
      arvores.splice(i, 1);
    }
  }

  if (frameCount % (120 - faseDificuldade * 10) === 0) {
    lixos.push(new Lixo(random(0, largura), -20));
  }

  for (let i = lixos.length - 1; i >= 0; i--) {
    lixos[i].move();
    lixos[i].display();

    for (let j = arvores.length - 1; j >= 0; j--) {
      if (!ferramentaAtiva && lixos[i] && lixos[i].hits(arvores[j])) {
        arvores.splice(j, 1);
        pontos -= 100;
        lixos.splice(i, 1);
        break;
      }
    }

    if (lixos[i] && lixos[i].y > altura) {
      lixos.splice(i, 1);
    }
  }

  if (pontos >= fase * 100) {
    fase++;
    faseDificuldade++;
    textSize(20);
    fill(255, 0, 0);
    text("Nova Fase!", largura / 2 - 50, altura / 2);
    text("Dificuldade Aumentada!", largura / 2 - 100, altura / 2 + 30);
  }

  showInfo();

  if (pontos <= 0) {
    gameOver = true;
  }

  if (ferramentaAtiva) {
    drawDefesaVisual();
  }

  if (ferramentaAtiva && frameCount - tempoDefesa > duracaoDefesa) {
    ferramentaAtiva = false;
  }
}

function desenharCenario() {
  noStroke();
  fill(60, 179, 113);
  rect(0, altura - gramaAltura, largura, gramaAltura);
  fill(255, 255, 0);
  ellipse(70, 70, 60, 60);
  fill(255);
  ellipse(200, 80, 60, 40);
  ellipse(230, 70, 60, 40);
  ellipse(260, 80, 60, 40);
}

function showGameOver() {
  textSize(32);
  fill(255, 0, 0);
  textAlign(CENTER, CENTER);
  text("Jogo Acabou!", largura / 2, altura / 2 - 40);
  textSize(20);
  text("Pontuação: " + pontos, largura / 2, altura / 2 + 10);
}

function showInfo() {
  textSize(16);
  fill(0);
  text("Temperatura: " + Math.round(temperatura) + "°C", 10, 30);
  text("Pontos: " + pontos, largura - 120, 30);
  text(ferramentaAtiva ? "Defesa Ativada!" : "Pressione F para Ativar Defesa", largura / 2 - 100, altura - 10);
  text("Fase: " + fase, 10, altura - 20);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) nina.move(-15, 0);
  else if (keyCode === RIGHT_ARROW) nina.move(15, 0);
  else if (keyCode === UP_ARROW) nina.move(0, -15);
  else if (keyCode === DOWN_ARROW) nina.move(0, 15);
  else if (key === ' ') {
    if (nina.y > altura - gramaAltura) arvores.push(new Arvore(nina.x, nina.y));
  } else if (key === 'F' || key === 'f') {
    if (!ferramentaAtiva) {
      ferramentaAtiva = true;
      tempoDefesa = frameCount;
    }
  }
}

function drawDefesaVisual() {
  push();
  translate(nina.x, nina.y);

  let pulsar = 150 + sin(frameCount * 0.2) * 10;
  noFill();
  stroke(0, 191, 255, 180);
  strokeWeight(4);
  ellipse(0, 0, pulsar);

  stroke(173, 216, 230, 150);
  strokeWeight(2);
  for (let a = 0; a < TWO_PI; a += PI / 6) {
    let x1 = cos(a + frameCount * 0.1) * 10;
    let y1 = sin(a + frameCount * 0.1) * 10;
    let x2 = cos(a + frameCount * 0.1) * pulsar / 2;
    let y2 = sin(a + frameCount * 0.1) * pulsar / 2;
    line(x1, y1, x2, y2);
  }

  pop();

  textSize(18);
  fill(30, 144, 255);
  textAlign(CENTER, CENTER);
  text("🛡 Defesa Ativada!", largura / 2, 40);
}

class Nina {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 40;
  }

  display() {
    // Corpo
    fill(255, 220, 180); // Pele
    ellipse(this.x, this.y - 20, 20); // Cabeça
    fill(255, 105, 180); // Roupa
    rect(this.x - 10, this.y - 10, 20, 30, 5); // Corpo

    // Cabelo
    fill(139, 69, 19); // Cabelo marrom
    arc(this.x, this.y - 30, 30, 30, PI, TWO_PI); // Cabelo

    // Rosto (olhos)
    fill(0); // Olhos pretos
    ellipse(this.x - 5, this.y - 25, 4); // Olho esquerdo
    ellipse(this.x + 5, this.y - 25, 4); // Olho direito

    // Braços
    fill(255, 220, 180); // Pele
    ellipse(this.x - 15, this.y, 10, 15); // Braço esquerdo
    ellipse(this.x + 15, this.y, 10, 15); // Braço direito

    // Pernas
    fill(0, 0, 255); // Calças
    rect(this.x - 8, this.y + 15, 8, 15); // Perna esquerda
    rect(this.x, this.y + 15, 8, 15); // Perna direita
  }

  update() {
    // Atualiza a posição do personagem (pode ser implementado com as teclas)
    this.x = constrain(this.x, 0, largura);
    this.y = constrain(this.y, altura - gramaAltura, altura);
  }

  move(dx, dy) {
    this.x += dx;
    this.y += dy;
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10;
    this.growthRate = 0.05;
  }

  display() {
    fill(139, 69, 19);
    rect(this.x - 5, this.y - this.size * 1.5, 10, this.size * 1.5);
    fill(34, 139, 34);
    ellipse(this.x, this.y - this.size * 1.5, this.size * 1.5);
  }

  grow(temp) {
    this.size += this.growthRate * (temp / 20);
  }
}

class Lixo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.vel = random(1.5, 3);
  }

  move() {
    this.y += this.vel;
  }

  display() {
    fill(169);
    rect(this.x - 8, this.y - 10, 16, 20, 3);
    fill(100);
    rect(this.x - 4, this.y - 15, 8, 5);
  }

  hits(arvore) {
    let d = dist(this.x, this.y, arvore.x, arvore.y);
    return d < (this.size / 2 + arvore.size / 2);
  }
}

class Passaro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vel = random(0.3, 0.8);
  }

  move() {
    this.x += this.vel;
    if (this.x > width + 30) {
      this.x = -30;
      this.y = random(50, 150);
    }
  }

  display() {
    fill(255);
    ellipse(this.x, this.y, 20, 10);
    ellipse(this.x + 10, this.y, 20, 10);
  }
}

class Gota {
  constructor() {
    this.x = random(width);
    this.y = random(-500, 0);
    this.vel = random(3, 6);
  }

  update() {
    this.y += this.vel;
    if (this.y > height) {
      this.y = random(-200, 0);
      this.x = random(width);
    }
  }

  display() {
    stroke(0, 255, 0, 150);
    line(this.x, this.y, this.x, this.y + 10);
  }
}

